import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @Input() title:string;
  username:string;
  password:string;
  message:string;
  status:string;
  pwdType:string;
  showPassword:boolean;
  pstyle:string="left";
  gender:string;
  education:string;
  sports:string;
  music:string;
  entertainment:string;

  @Output() loginEvent:EventEmitter<string>=new EventEmitter();

  constructor() {
    this.pwdType="password";
    // this.pstyle="left";
   }

  ngOnInit(): void {
  }

  fn1()
  {
    this.loginEvent.emit(this.username);
    // if(this.username=='rama' && this.password=='ravi')
    //  {
    //    this.status="success";
    //     this.message='Login is successful';
    //  } 
    // else
    // {
    //   this.status="failure";
    //   this.message='Login is failure';
    // } 
  }
  
  fnTogglePassword()
  {
    if(this.showPassword)
    { 
       this.pwdType="text";
       this.pstyle="text-align:right"
    }
    else
    {  this.pwdType="password";
    this.pstyle="text-align:left"
  }
  }
}
