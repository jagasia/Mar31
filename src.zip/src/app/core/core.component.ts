import { Component, OnInit } from '@angular/core';
import { Student } from '../student';

@Component({
  selector: 'app-core',
  templateUrl: './core.component.html',
  styleUrls: ['./core.component.css']
})
export class CoreComponent implements OnInit {
  months = ["Jan", "Feb", "Mar", "April", "May", "Jun",
"July", "Aug", "Sept", "Oct", "Nov", "Dec"];

  str:string='this is a string';
  dt:Date=new Date();
  x:number=15467.458;
  raja:Student=new Student();
  constructor() {
    this.raja.studentId=123;
    this.raja.firstName='Raja';
    this.raja.lastName='Siva kumar';
   }

  ngOnInit(): void {
  }


}
