import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  username: string;
  password: string;
  cpassword: string;
  usernameMessage:string;
  pwdMessage: string;
  dobMessage: string;
  status: string;
  dateOfBirth: string;
  constructor() {
    this.username="";
  }

  ngOnInit(): void {
  }

  fnCheckPwds() {
    if (this.password != this.cpassword) {
      this.status = "failure";
      this.pwdMessage = "Passwords does not match";
    } else {
      this.status = "success";
      this.pwdMessage = "";
    }
  }

  fnCheckDate() {
    var dob = new Date(this.dateOfBirth);
    var today = new Date();
    if (dob > today) {
      this.status = "failure";
      this.dobMessage = "Date of Birth cannot be future date";
    } else {
      this.dobMessage = "";
    }
  }

  fnUserName()
  {   
    if(this.username.length==0)
    {
      this.status = "failure";
      this.usernameMessage="User Namme cannot be blank";
    }
    else
    this.usernameMessage='';
  }
}
