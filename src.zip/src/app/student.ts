export class Student {
    studentId:number;
    firstName:string;
    lastName:string;
}
